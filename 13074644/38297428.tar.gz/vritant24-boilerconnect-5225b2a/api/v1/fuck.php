

Details  	->Done
Crn			->Done
Course		->Done
Login		->Done
Public		->Done
Add 		->Done
Enroll		->Done
Drop		->Done
