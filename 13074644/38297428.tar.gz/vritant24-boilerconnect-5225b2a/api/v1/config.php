<?php 
	//error_reporting(0);
	define("host", "localhost");
	define("dbuser","root");
	define("dbpassword","");
	define("dbname","boiler");
?>