import React from 'react';

export default function Dot(props) {
  return(
    <td className="Dot" />
  );
}
