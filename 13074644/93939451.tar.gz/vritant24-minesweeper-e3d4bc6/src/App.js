import React, { Component } from 'react';
import MineSweeper from './components/MineSweeper.jsx';

class App extends Component {
  render() {
    return (
      <MineSweeper />
    );
  }
}

export default App;
