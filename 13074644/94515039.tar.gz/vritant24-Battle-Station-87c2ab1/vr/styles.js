import theme from "./theme";

export default {
    helloText: {
        backgroundColor: theme.COLOR.PRIMARY,
        fontSize: 0.8,
        fontWeight: "400",
        layoutOrigin: [0.5, 0.5],
        paddingLeft: 0.2,
        paddingRight: 0.2,
        textAlign: "center",
        textAlignVertical: "center",
        transform: [{translate: [0, 0, -3]}],
    },
    listBox: {
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        position: "absolute",
        transform: [
            { translate: [-5, 1, 0] },
            { rotateY: 90 }
        ],
        height: 1.5
    },
    button: {
        backgroundColor: theme.COLOR.ACCENT,
        paddingHorizontal: 0.2,
        marginHorizontal: 0.2,
        width: 1
    },
    buttonText: {
        fontSize: 0.2,
        fontWeight: "400",
        textAlign: "center",
        textAlignVertical: "center"
    },
    list: {
        display: "flex",
        flexDirection: "column"
    },
    listItem: {
        display: "flex",
        flexDirection: "row",
        backgroundColor: theme.COLOR.LIGHTTEXT,
        padding: 0.05,
        marginTop: 0.2
    },
    listItemIcon: {
        height: 0.1,
        width: 0.1,
        marginRight: 0.2
    },
    listItemText: {
        fontSize: 0.1,
        fontWeight: "400",
        textAlign: "center",
        textAlignVertical: "center",
        color: theme.COLOR.DARKTEXT
    },
    appBox: {
        backgroundColor: theme.COLOR.TRANSLUCENT,
        transform: [
            { translate: [-3, 2.5, 3] },
            { rotateY: 180 },
            { rotateX: -5 }
        ],
        height: 3,
        width: 6
    },
    cylinder: {
        position: "absolute",
        transform: [
            { translate: [5.5, -4, 0] },
            { rotateY: 270 },
        ],
    },
    cylinderView: {
        opacity: 1,
        width: 1300,
        height: 650,
        flex: 1,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-around",
    },
    cylinderBox: {
        alignSelf: "stretch",
        width: 400,
        backgroundColor: theme.COLOR.TRANSLUCENT,
    },
    cylinderText: {
        margin: 5,
        fontSize: 70,
        fontWeight: "300",
        borderRadius: 20,
        color: theme.COLOR.DARKTEXT,
        // backgroundColor: theme.COLOR.GREY,
    }
};
