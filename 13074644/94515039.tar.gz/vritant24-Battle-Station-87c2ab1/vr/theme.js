export default {
    COLOR: {
        PRIMARY: "#FF5A5F",
        ACCENT: "#6153CC",
        DARKSHADOW: "rgba(0, 0, 0, 0.1)",
        LIGHTSHADOW: "rgba(255, 255, 255, 0.4)",
        TRANSPARENT: "transparent",
        DARKTEXT: "#221D23",
        LIGHTTEXT: "#FCF8F9",
        GREY: "#757575",
        TRANSLUCENT: "rgba(255, 255, 255, 0.6)",
    }
}
