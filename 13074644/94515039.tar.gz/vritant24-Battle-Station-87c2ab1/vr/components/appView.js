import React, { Component } from "react";
import { View, Text } from "react-vr";

export default class AppView extends Component {
    render() {
        return (
            <View style={this.props.style}>

            </View>
        );
    }
}
