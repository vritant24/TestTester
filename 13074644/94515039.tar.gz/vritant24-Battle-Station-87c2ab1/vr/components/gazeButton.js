import React, { Component } from "react";
import { View, VrButton } from "react-vr";

export default class extends Component {
    constructor(props) {
        super(props);
        this.state = {
            beingLookedAt: false,
            remainingTime: 0,
            duration: props.duration ? props.duration : 2000
        }
    }

    componentDidMount() {
        this.resetRemainingTime();
    }

    componentWillUnmount() {
        this.clearCountdown();
    }

    handleClick = () => {
        const { onClick } = this.props;
        this.clearCountdown();
        onClick();
    }

    handleEnter = () => {
        const { onClick } = this.props;
        const { duration } = this.state;
        const endTime = Date.now() + (duration || 2000);
        this.setState({ beingLookedAt: true });
        this.countdown = setInterval(() => {
            const currentTime = Date.now();
            if (!this.state.beingLookedAt) {
                this.clearCountdown();
            } else if (currentTime > endTime) {
                this.handleClick();
            } else {
                this.setState({ remainingTime: endTime - currentTime });
            }
        }, 16);
    }

    handleExit = () => {
        this.setState({ beingLookedAt: false });
        this.props.onExit();
    }

    resetRemainingTime = () => {
        const { duration } = this.state;
        this.setState({ remainingTime: duration || 2000 });
    }

    clearCountdown = () => {
        const { duration } = this.state;
        clearInterval(this.countdown);
        this.setState({ remainingTime: duration || 2000 });
    }

    render() {
        return (
            <View 
                onEnter={this.handleEnter}
                onExit={this.props.onExit ? this.handleExit : null}
                style={this.props.style || {}}>
                <VrButton onClick={this.handleClick}>
                    {React.cloneElement(this.props.children, {
                        remainingTime: this.state.remainingTime
                    })}
                </VrButton>
            </View>
        );
    }
}
