import React from "react";
import {
    AppRegistry,
    asset,
    Pano,
    Image,
    Text,
    View,
    CylindricalPanel
} from "react-vr";
import { GazeButton } from "./vr/components";
import styles from "./vr/styles";

const test = [
    { name: "Twitter", img: "https://upload.wikimedia.org/wikipedia/en/thumb/9/9f/Twitter_bird_logo_2012.svg/300px-Twitter_bird_logo_2012.svg.png" },
    { name: "Facebook", img: "https://images.seeklogo.net/2016/09/facebook-icon-preview-200x200.png" },
    { name: "Google +", img: "https://images.vexels.com/media/users/3/137283/isolated/preview/8ca486faebd822ddf4baf00321b16df1-google-icon-logo-by-vexels.png" },
    { name: "RSS", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Generic_Feed-icon.svg/500px-Generic_Feed-icon.svg.png" },
    { name: "Yahoo", img: "http://i.imgur.com/VpAwbwS.png" }
]

export default class Battle_Station extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            loaded: false
        };
    }

    load = () => {
    if(this.state.loaded) {
        return;
    }
        this.setState(
            { loading: true },
            () => setTimeout(() => this.setState({ loaded: true, loading: false }), 1000)
        );
    }

    render() {
        const items = test && test.map((item, index) => (
            <View key={index} style={styles.listItem}>
                <Image style={styles.listItemIcon} source={{uri: item.img }}/>
                <Text style={styles.listItemText}>{item.name}</Text>
            </View>
        ));
        const textItems = test && test.map((item, index) => (
            <Text style={styles.cylinderText}>{item.name}</Text>
        ));
        return (
            <View>
                <Pano source={asset("chess-world.jpg")}/>
                <Text
                    style={styles.helloText}>
                    hello
                </Text>
                <View style={styles.listBox}>
                    <GazeButton onClick={this.load} style={styles.button}>
                        <Text style={styles.buttonText}>Stare here to fill List</Text>
                    </GazeButton>
                    {this.state.loading && <Text style={styles.buttonText}>Loading...</Text>}
                    {this.state.loaded && <View style={styles.list}>
                        {items}
                    </View>}
                </View>
                <View style={styles.appBox}>
                    <Text style={styles.buttonText}>This is cool</Text>
                </View>
                <CylindricalPanel
                    style={styles.cylinder}
                    layer={{
                        width: 1300,
                        height: 700,
                        radius: 60,
                    }}>
                    <View style={styles.cylinderView}>
                      <View style={styles.cylinderBox}>
                        {textItems}
                      </View>
                      <View style={styles.cylinderBox}>
                        {textItems}
                      </View>
                      <View style={styles.cylinderBox}>
                        {textItems}
                      </View>
                    </View>
                </CylindricalPanel>
            </View>
        );
    }
};

AppRegistry.registerComponent("Battle_Station", () => Battle_Station);
