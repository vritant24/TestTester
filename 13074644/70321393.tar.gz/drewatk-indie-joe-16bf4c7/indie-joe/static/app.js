$(document).ready(function() {
    $('.center-carousel').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        prevArrow: false,
        nextArrow: false,
        pauseOnFocus: true,
        useCSS: true
    });
});
