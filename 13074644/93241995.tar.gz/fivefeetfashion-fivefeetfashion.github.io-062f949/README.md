# fivefeetfashion.github.io
Fashion Blog

This is where the contents of the `build` folder in the repo `fivefeetfashion/website` are used to host the fashion blog on `fivefeetfashion.github.io`
