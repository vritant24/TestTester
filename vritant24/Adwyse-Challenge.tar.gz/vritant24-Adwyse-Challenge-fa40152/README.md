# Adwyse-Challenge
Adwyse Coding Challenge

Problem 1 - in Javascript and Tests using Mocha and Chai
To see problem1 solution in action, the console on a browser can be used on index.html.
Use ```problem1.main(element,array)``` to use your own values.

For seeing prolem1 tests in action, run ```npm install``` to install required modules for mocha and chai.
execute ```npm run test``` for running the tests.


Problem 2 - in Java, and tests using jUnit tests.
Can be imported into eclipse as an existing project
